package com.tweetapp.Main;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Session;

import com.tweetapp.TableUi.TableList;
import com.tweetapp.config.HibernateConfigure;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;
import com.tweetapp.service.TweetService;
import com.tweetapp.service.UserService;

public class Main {

	static UserService us = new UserService();

	static TweetService ts = new TweetService();

	public static void main(String[] args) {

		Session session = HibernateConfigure.getSessionFactory().openSession();
		User u;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("\nENTER CHOICE \n1.LOGIN \n2.REGISTER \n3.FORGOT PASSWORD? \n");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				// LOGGING IN CODE
				System.out.println("ENTER USERNAME:");
				String username = sc.next();
				System.out.println("ENTER PASSWORD:");
				String password = sc.next();
				u = us.login(session, username, password);

				int ch1 = 0;
				if (u != null) {
					System.out.println("LOGIN SUCCESSFUL!!");
					do {
						ch1 = 0;
						System.out.println("\nENTER CHOICE \n1. POST A TWEET\r\n" 
								+ "\r\n" + "2. VIEW MY TWEETS\r\n"
								+ "\r\n" + "3. VIEW ALL TWEETS\r\n" 
								+ "\r\n" + "4. VIEW ALL Users\r\n" + "\r\n"
								+ "5. RESET PASSWORD6"
								+ "\r\n" + "\r\n" + "6. LOGOUT \n");
						ch1 = sc.nextInt();
						switch (ch1) {
						case 1:
							// POST OR ADD A NEW TWEET
							Tweet obj = new Tweet();
							System.out.println("ENTER THE MESSAGE YOU WANT TO SHARE...");
							sc.nextLine();
							String tweetmsg = sc.nextLine();
							obj.setTweetMsg(tweetmsg);
							obj.setUserName(u.getUserName());
							ts.saveTweet(session, obj);
							break;

						case 2:
							// VIEW MY TWEETS
							List<Tweet> mytweets = ts.getallbyusername(session, u.getUserName());
							TableList tl = new TableList(4, "ID", "TWEET", "TIME", "USERNAME");
							// PRINTING ALL FROM LIST IN A TABULAR MANNER
							mytweets.forEach(element -> tl.addRow(String.valueOf(element.getId()),
									element.getTweetMsg(), (element.getTweetTime()).toString(), element.getUserName()));
							tl.print();
							break;

						case 3:
							// VIEW ALL TWEETS OF ALL USERS
							List<Tweet> alltweets = ts.getAlltweets(session);
							// PRINTING ALL FROM LIST IN A TABULAR MANNER
							TableList t2 = new TableList(4, "ID", "TWEET", "TIME", "USERNAME");
							alltweets.forEach(element -> t2.addRow(String.valueOf(element.getId()),
									element.getTweetMsg(), (element.getTweetTime()).toString(), element.getUserName()));
							t2.print();
							break;

						case 4:
							// VIEW ALL USERS
							List<User> allusers = us.getAllUsers(session);
							TableList t3 = new TableList(4, "FIRST NAME", "LAST NAME", "EMAIL ID", "GENDER");
							// PRINTING ALL FROM LIST IN A TABULAR MANNER
							allusers.forEach(element -> t3.addRow(element.getFirstName(), element.getLastName(),
									element.getUserName(), element.getGender()));
							t3.print();
							break;

						case 5:
							// RESET PASSWORD
							System.out.println("ENTER YOUR OLD PASSWORD");
							String old = sc.next();
							if (old.equals(u.getPasswd())) {
								System.out.println("ENTER YOUR NEW PASSWORD");
								String new1 = sc.next();
								System.out.println("CONFIRM NEW PASSWORD");
								String confirm = sc.next();
								if (new1.equals(confirm)) {
									// USER INVOKES setPasswd() METHOD IN UserService.java
									u.setPasswd(confirm);
									us.resetPasswd(session, u);
									System.out.println("PASSWORD RESET SUCCESSFUL!");
								} else {
									System.out.println("CONFIRM PASSWORD MISMATCH");
								}
							} else {
								System.out.println("INCORRECT OLD PASSWORD");
							}
							break;

						case 6:
							// LOGOUT
							u = null;
							System.out.println("LOGOUT SUCCESSFUL!");
							break;
						}
					} while (ch1 != 6);
				}
				else {
					System.out.println("INCORRECT USERNAME OR PASSWORD");
					u=null;
				}
				break;

			case 2:
				// REGISTER NEW USER CODE
				System.out.println("ENTER FIRST NAME:");
				String fname = sc.next();
				System.out.println("ENTER LAST NAME:");
				String lname = sc.next();
				System.out.println("ENTER GENDER:");
				String gender = sc.next();
				String uname;
				do{
				System.out.println("ENTER EMAIL ADDRESS:");
				 uname= sc.next();
				 String regex = "^(.+)@(.+)$";  
			       Pattern pattern = Pattern.compile(regex);   
			            Matcher matcher = pattern.matcher(uname);  
			            if(!matcher.matches())
			            {
			            	System.out.println("PLEASE ENTER VALID EMAIL ADDRESS");
			      
			            }else {
			            	break;
			            }
				}while(true);
				System.out.println("ENTER PASSWORD:");
				String passwd = sc.next();
				User u1 = new User();
				u1.setFirstName(fname);
				u1.setLastName(lname);
				u1.setGender(gender);
				u1.setPasswd(passwd);
				u1.setUserName(uname);
				us.register(session, u1);
				break;

			case 3:
				System.out.println("ENTER EMAIL ADDRESS:");
				String email = sc.next();
				String regex = "^(.+)@(.+)$";
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(email);
				if (matcher.matches()) {

					boolean b = us.forgotPassword(session, email);
					if (b) {
						System.out.println("ENTER OTP:");
						String otp = sc.next();
						boolean bool = us.verifyOtp(session, email, otp);
						if (bool) {
							System.out.println("ENTER YOUR NEW PASSWORD");
							String new1 = sc.next();

							System.out.println("CONFIRM NEW PASSWORD");
							String confirm = sc.next();
							if (new1.equals(confirm)) {
								// call service to set passwd function;
								us.changepasswd(session, email, new1);
								System.out.println("PASSWORD RESET SUCCESSFUL!");
							} else {
								System.out.println("CONFIRM PASSWORD MISMATCH");
							}
						}
					}
				} else {
					System.out.println("INCORRECT EMAIL ADDRESS");
				}

			default:
				System.out.println("ENTER VALID CHOICE");
				break;
			}

		}

	}

}
